package com.exampleClassObject;

class Car {
    void start() {
        System.out.println("Car is starting");
    }
}

public class Main {
    public static void main(String[] args) {
        Car myCar = new Car(); // object created
        myCar.start();        
    }
}
