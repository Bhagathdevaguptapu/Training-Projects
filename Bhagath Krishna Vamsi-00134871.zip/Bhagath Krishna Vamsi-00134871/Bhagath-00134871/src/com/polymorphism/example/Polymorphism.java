package com.polymorphism.example;

class Animal{
	void sound() {
		System.out.println("Animal makes a sound");
	}
}

class Lion extends Animal{
	void sound() {
		System.out.println("Lions Roars");
	}
}

public class Polymorphism {

	public static void main(String[] args) {
		Animal al = new Lion();
		al.sound();
	}

}
