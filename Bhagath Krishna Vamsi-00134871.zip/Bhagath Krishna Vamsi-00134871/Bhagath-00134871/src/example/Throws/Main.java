package example.Throws;

class InvalidUsernameException extends Exception {
    public InvalidUsernameException(String message) {
        super(message);
    }
}

public class Main {
    public static void validateUsername(String username) throws InvalidUsernameException {
        if (!username.matches("[a-zA-Z]{5,}")) {
            throw new InvalidUsernameException("Username must be at least 5 letters long and alphabetic.");
        }
    }

    public static void main(String[] args) {
        try {
            validateUsername("bh"); 
        } catch (Throwable t) {  // Catching using Throwable
            System.out.println("Exception Caught: " + t.getMessage());
        }
    }
}
