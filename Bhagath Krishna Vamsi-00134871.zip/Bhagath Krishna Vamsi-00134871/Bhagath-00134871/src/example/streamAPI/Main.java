package example.streamAPI;

import java.util.*;
import java.util.stream.*;

class Employee {
    String name;
    int id;
    double salary;

    public Employee(String name, int id, double salary) {
        this.name = name;
        this.id = id;
        this.salary = salary;
    }
}

public class Main {
    public static void main(String[] args) {
        List<Employee> list = Arrays.asList(
            new Employee("John", 1, 1200),
            new Employee("Mike", 2, 800),
            new Employee("Sara", 3, 1500)
        );

        list.stream()
            .filter(emp -> emp.salary > 1000)
            .forEach(emp -> System.out.println(emp.name + " - " + emp.salary));
    }
}

