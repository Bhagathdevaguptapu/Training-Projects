package example.streams;

import java.util.*;

class Employee {
    String name;

    public Employee(String name) {
        this.name = name;
    }
}

public class Main {
    public static void main(String[] args) {
        List<Employee> list = Arrays.asList(
            new Employee("John"),
            new Employee("Mike"),
            new Employee("Sara")
        );

        list.stream()
            .map(e -> e.name.toUpperCase()) 
            .forEach(System.out::println);  
    }
}
