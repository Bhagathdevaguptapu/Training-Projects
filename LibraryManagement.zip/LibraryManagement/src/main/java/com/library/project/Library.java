package com.library.project;

import lombok.Data;

@Data
public class Library{
	public String book;
	public String author;
}
