package com.library.project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;


@SpringBootApplication
public class LibraryManagementApplication {

	public static void main(String[] args) {
		ConfigurableApplicationContext context =  SpringApplication.run(LibraryManagementApplication.class, args);
		LibraryRepository lib = context.getBean(LibraryRepository.class);
		lib.getBookDetils("oracle");
	}

}
