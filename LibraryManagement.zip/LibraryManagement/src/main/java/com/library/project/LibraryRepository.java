package com.library.project;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class LibraryRepository {
	@Autowired
	JdbcTemplate template;
	
	@Autowired
	NamedParameterJdbcTemplate namedTemplate;
	
	public void getBookDetils(String author) {
		MapSqlParameterSource namedParameters = new MapSqlParameterSource();
		namedParameters.addValue("author",author);
		String book = namedTemplate.queryForObject("select book from books where author=:author", namedParameters, String.class);
		System.out.println("book name: "+book+ "Author name"+author);
	}
}
