package com.library.project;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;


public class LibraryRowMapper implements RowMapper<Library>{
	
	@Override
	public Library mapRow(ResultSet rs, int rowNum) throws SQLException {
		Library lib = new Library();
		lib.setBook(rs.getString("book"));
		lib.setAuthor(rs.getString("author"));
		return lib;
	}
}
