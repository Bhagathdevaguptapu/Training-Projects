package cfg.lms.bms;

public class BookEntity {

}
