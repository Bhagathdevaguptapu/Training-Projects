package cfg.lms.bms;

import java.util.Optional;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import cfg.lms.onetoone.BranchEntity;
import cfg.lms.onetoone.BranchRepository;
import cfg.lms.onetoone.CustomerEntity;

@SpringBootApplication(scanBasePackages = {"cfg.lms"})
@EntityScan("cfg.lms")
@EnableJpaRepositories("cfg.lms")
public class BookManagementLibraryApplication {

	public static void main(String[] args) {
		ConfigurableApplicationContext context = SpringApplication.run(BookManagementLibraryApplication.class, args);
//		BankRepository bankRepo = context.getBean(BankRepository.class);
//		List<BankEntity> bankEntities = bankRepo.findAll();
//		for(BankEntity bank:bankEntities) {
//			System.out.println(bank.getName()+"-->"+bank.getBranch().getLocation());;
//		}
		
		
		BranchRepository branchRepo = context.getBean(BranchRepository.class);
		Optional<BranchEntity> branch = branchRepo.findById(1);
		if(branch.isPresent()) {
			for(CustomerEntity customer : branch.get().getCustomers()) {
				System.out.println(customer.getCname());
			}
			System.out.println("-------------------------");
		}
	}

}
