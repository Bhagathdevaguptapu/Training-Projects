package cfg.lms.onetoone;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Data
@Table(schema = "sbi", name = "customer")
public class CustomerEntity {
	@Id
	private int cid;
	
	@Column
	private String cname;
	
	@OneToOne
	@JoinColumn(name = "loginId",
	referencedColumnName = "id")
	private LoginEntity login;
	
	@ManyToOne
	@JoinColumn(name = "brid",
	referencedColumnName = "branchId")
	private BranchEntity branch;
}
