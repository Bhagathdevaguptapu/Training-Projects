package cfg.lms.onetoone;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Data
@Table(schema = "sbi", name = "login")
public class LoginEntity {
	
	@Id
	private int id;
	
	@Column
	private String username;
	
	@Column
	private String password;
	

//	@OneToOne(mappedBy = "login")
//	private CustomerEntity customer;
}
