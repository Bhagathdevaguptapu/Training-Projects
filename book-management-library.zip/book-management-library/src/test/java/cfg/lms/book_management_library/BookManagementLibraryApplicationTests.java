package cfg.lms.book_management_library;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookManagementLibraryApplicationTests {

	@Test
	void contextLoads() {
	}

}
