package cfg.lms.bm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

@SpringBootApplication
public class BookManagementApplication {

	public static void main(String[] args) {
		ConfigurableApplicationContext context =  SpringApplication.run(BookManagementApplication.class, args);
		EmployeeRepository emp = context.getBean(EmployeeRepository.class);
		emp.getEmployeeCount();
		emp.getEmployee("durga");	  
		emp.printEmployee();
		emp.addEmployee("bhagath");
	}

	
}
