package cfg.lms.bm;

import lombok.Data;

@Data
public class Employee {
	public int empId;
	public String empNm;
}
