package cfg.lms.bm;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.object.MappingSqlQueryWithParameters;
import org.springframework.stereotype.Repository;

@Repository
public class EmployeeRepository {
	@Autowired
	JdbcTemplate template;
	
	@Autowired
	NamedParameterJdbcTemplate namedTemplate;
	
	public void getEmployeeCount() {
		int count = template.queryForObject("select count(*) from employee",Integer.class);
		System.out.println("employee count: "+count);
	}
	
	public void getEmployee(String empINm) {
		MapSqlParameterSource namedParameters = new MapSqlParameterSource();         
		namedParameters.addValue("empnm", empINm);
		int id = namedTemplate.queryForObject("select id from employee where name=:empnm",namedParameters,Integer.class);
		System.out.println("employee id: "+id);
	}
	
	public void printEmployee() {
//		List<Integer> count = template.queryForList("select id from employee",Integer.class);
//		List<String> name = template.queryForList("select name from employee",String.class);
//		System.out.println(count);
//		System.out.println(name);
		
		List<Employee> employee = template.query("select * from employee", new EmployeeRowMapper());
		for(Employee emp:employee) {
			System.out.println(emp.getEmpId()+"------"+emp.getEmpNm());
		}
	}
	
	public void addEmployee(String empINm) {
		int maxId = template.queryForObject("select max(id) from employee", Integer.class);
		
		MapSqlParameterSource namedParams = new MapSqlParameterSource();
		
		namedParams.addValue("id", maxId+1);
		namedParams.addValue("empNm", empINm);
		namedTemplate.update("insert into employee values(:id, :empNm)",namedParams);
		
		System.out.println("-----values inserted------");
	}
	
	public void deleteEmployee(String empINm) {
		MapSqlParameterSource namedParams = new MapSqlParameterSource();
		namedParams.addValue("empNm", empINm);
		namedTemplate.update("delete from employee where name(:empNm)",namedParams);
		
		System.out.println("-----values deleted------");
	}
	
	public void updateEmployee(int id, String name) {
	    MapSqlParameterSource namedParams = new MapSqlParameterSource();
	    namedParams.addValue("id", id);
	    namedParams.addValue("name", name);

	    namedTemplate.update("UPDATE employee SET name = :name WHERE id = :id", namedParams);

	    System.out.println("-----values updated------");
	}

	
}