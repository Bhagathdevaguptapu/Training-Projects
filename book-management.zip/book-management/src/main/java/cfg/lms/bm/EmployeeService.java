package cfg.lms.bm;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class EmployeeService {
	
	@Autowired
	EmployeeRepository repo;
	
	public void initAction(String option) {
		switch(option) {
		case "a":
			repo.addEmployee("krishna");
			break;
		case "b":
			repo.getEmployeeCount();
			break;
		}
	}
}
