package cfg.lms.lum;

import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Data
@Table(schema="cinema")
public class Movie {
	@Id
	private String movId;
	
	private String title;
	
	@OneToMany(mappedBy = "movie")
	private List<Theater> theater;

}