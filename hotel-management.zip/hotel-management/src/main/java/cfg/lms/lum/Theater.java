package cfg.lms.lum;

import jakarta.persistence.Column;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

public class Theater {
	@Id
	private int tid;
	
	@ManyToOne
	@JoinColumn(name="dirId")
	private Director director;
	
	@ManyToOne
	@JoinColumn(name="movId")
	private Movie movie;
	
	@Column
	private double budget;

}
