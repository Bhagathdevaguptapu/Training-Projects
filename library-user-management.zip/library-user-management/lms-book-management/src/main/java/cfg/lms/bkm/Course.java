package cfg.lms.bkm;

import lombok.Data;

@Data
public class Course {
	private int cid;
	private String name;
}
