package cfg.lms.bkm;

import org.springframework.stereotype.Component;

import lombok.Data;

@Component("librarian")
@Data
public class Librarian extends User {
	private double salary;

}
