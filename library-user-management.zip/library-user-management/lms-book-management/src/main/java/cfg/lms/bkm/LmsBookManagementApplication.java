package cfg.lms.bkm;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.support.ClassPathXmlApplicationContext;

@SpringBootApplication
public class LmsBookManagementApplication {

	public static void main(String[] args) {
		
		//ConfigurableApplicationContext context=SpringApplication.run(LmsBookManagementApplication.class, args);
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
		Student st = context.getBean(Student.class);
//		System.out.println(st.getStudentName());
		System.out.println(st.getCourse().getName());
//		Author author = context.getBean(Author.class);
//		author.setAid(1);
//		author.setName("Bhagath");
//		
//		Book book = context.getBean(Book.class);
//		
////		User user1 = context.getBean(User.class);
////		user1.setName("Bhagath");
////		user1.setUserId(1);
//		
//		User user2 = context.getBean(Customer.class);
//		user2.setName("Krishna");
//		user2.setUserId(2);
//		
//		User user3 = context.getBean(Librarian.class);
//		user3.setName("Vamsi");
//		user3.setUserId(3);
//		
//		Book book1 = context.getBean(Book.class);
//		System.out.println(book1.getUser().getName());
//		Book book2 = context.getBean(Book.class);
//		System.out.println(book2.getUser().getName());
		
		
//		book.setAuthor(author);
//		book.setBookID(2);
//		book.setTitle("Java");
//		System.out.println(author.getAid());
//		System.out.println(author.getName());
//		System.out.println(author.getAuthor());
//		System.out.println(author.getClass());
	}

}
