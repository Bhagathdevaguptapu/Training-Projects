package cfg.lms.bkm;

import org.springframework.stereotype.Component;

import lombok.Data;

@Component
@Data
public class User {
	private int userId;
	private String name;
}
