package cfg.lms.bkm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LmsBookManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
