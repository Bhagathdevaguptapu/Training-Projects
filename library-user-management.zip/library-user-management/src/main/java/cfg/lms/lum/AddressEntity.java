package cfg.lms.lum;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Table(schema ="library", name="address")
@Data
public class AddressEntity {
	
	@Id
	private int id;
	 
	@Column
	private String location;
	
//	@OneToMany(mappedBy = "adrs")
//	@ToString.Exclude
//	private List<EmployeeEntity> employee;
}
