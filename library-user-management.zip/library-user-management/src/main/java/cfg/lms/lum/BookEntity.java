package cfg.lms.lum;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Table(schema = "library", name="books")
@Data
public class BookEntity {
	@Id
	@Column(name="uid")
	private int bookId;
	
	@Column
	private String name;
	
	@Column
	private String author;
}
