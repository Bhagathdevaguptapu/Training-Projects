package cfg.lms.lum;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import jakarta.transaction.Transactional;


@Repository
@Transactional
public interface BookRepository extends JpaRepository<BookEntity, Integer>{
	//List<BookEntity> findByNameOrAuthor(String name,String author);
	
//	@Query("from library.books b where b.author=:name or b.name=:name")
//	List<BookEntity> findByNameOrAuthor(String name);
	
	@Query(value = "select * from library.books b where b.author=:name or b.name=:name", nativeQuery=true)
	List<BookEntity> findByNameOrAuthor(String name);
}
