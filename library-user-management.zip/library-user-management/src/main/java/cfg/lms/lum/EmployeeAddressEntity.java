package cfg.lms.lum;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Data
@Table(schema = "library", name = "employee")
public class EmployeeAddressEntity {
	@Id
	private int id;
	
	@ManyToOne
	@JoinColumn(name = "empid", referencedColumnName = "id")
	private EmployeeEntity emp;
	
	@ManyToOne
	@JoinColumn(name = "adrsid", referencedColumnName = "id")
	private AddressEntity adr;
}
