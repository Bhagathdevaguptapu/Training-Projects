package cfg.lms.lum;

import java.util.Optional;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

@SpringBootApplication
public class LibraryUserManagementApplication {

	public static void main(String[] args) {
		ConfigurableApplicationContext context = SpringApplication.run(LibraryUserManagementApplication.class, args);
		//BookRepository repo = context.getBean(BookRepository.class);
		EmployeeRepository epo = context.getBean(EmployeeRepository.class);
		
		//Search all books in table
//		List<BookEntity> books = repo.findAll();
//		for(BookEntity book: books) {
//			System.out.println(book.getName()+" "+ book.getAuthor());
//		}

		
		//Search by id
//		Optional<BookEntity> book = repo.findById(3);
//		if(book.isPresent()) {
//			System.out.println(book.get().getName()+"-----"+book.get().getAuthor());
//		}
		
		
		//Search by author or book name
//		List<BookEntity> books = repo.findByNameOrAuthor("Google");
//		for(BookEntity book: books) {
//			System.out.println(book.getName()+" "+ book.getAuthor());
//		}
		
		
		//Insert then details 
//		BookEntity book = new BookEntity();
//		book.setBookId(9);
//		book.setName("docker");
//		book.setAuthor("devops");
//		repo.save(book);
		
		
		//Delete by id
//		repo.deleteById(9);
		
		
		
		Optional<EmployeeEntity> employee = epo.findById(3);
		if(employee.isPresent()) {
			//System.out.println(employee.get().getAdrs().getName());
			System.out.println(employee.get().getName());
			System.out.println(employee.get().getId());
		}
		
	}
}
