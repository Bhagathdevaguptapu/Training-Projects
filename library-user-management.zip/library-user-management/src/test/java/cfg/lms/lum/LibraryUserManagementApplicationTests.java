package cfg.lms.lum;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibraryUserManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
