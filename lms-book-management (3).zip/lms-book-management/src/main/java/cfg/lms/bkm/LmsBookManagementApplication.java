package cfg.lms.bkm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LmsBookManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(LmsBookManagementApplication.class, args);
	}

}
