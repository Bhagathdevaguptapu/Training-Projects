package cfg.lms.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import cfg.lms.Service.EmployeeService;
import cfg.lms.Service.bo.Employee;

@RestController
public class EmployeeController {

	 @Autowired
	 EmployeeService service;

	 @GetMapping("/fetch-employee-data/")
	 public ResponseData fetchEmployeesData() {
		 ResponseData output = new ResponseData();
		 List<Employee> employees = service.fetchEmployeesData();
		 output.setData(employees);
		 output.setMessage("These are employee data");
		 output.setStatus("Success");
		 return output;
	 }

	 @GetMapping("/fetch-employee-data/{id}")
	 public ResponseData fetchEmployeeDataById(@PathVariable int id) {
		 ResponseData output = new ResponseData();
		 Employee emp = service.fetchEmployeeDataById(id);
		 if(emp!=null) {
			 output.setStatus("Success");
			 output.setData(emp);
		 }
		 else {
			 output.setStatus("Failed");
			 output.setMessage("Employee not found");
		 }
		 return output;
	 }
	 
	 
//	 @GetMapping("/employees/high-salary")
//	 public List<Employee> fetchHighSalaryEmployees() {
//	 	return service.fetchHighSalaryEmployees();
//	 }
}
