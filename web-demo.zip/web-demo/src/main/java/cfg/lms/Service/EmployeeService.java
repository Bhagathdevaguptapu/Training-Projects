package cfg.lms.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cfg.lms.Entity.EmployeeEntity;
import cfg.lms.Repository.EmployeeRepository;
import cfg.lms.Service.bo.Employee;

@Service
public class EmployeeService {
    
	@Autowired
	EmployeeRepository repo;
	
	public List<Employee> fetchEmployeesData() {
		List<EmployeeEntity> entities = repo.findAll();
		return entities.stream().map(e-> {
			Employee emp = new Employee();
			emp.setId(e.getId());
			emp.setName(e.getName());
			return emp;
		}).collect(Collectors.toList());
	}
	
	public Employee fetchEmployeeDataById(int id) {
		Optional<EmployeeEntity> optional = repo.findById(id);
		Employee emp= null;
		if (optional.isPresent()) {
            EmployeeEntity e = optional.get();
            emp = new Employee();
            emp.setId(id);
            emp.setSalary(e.getSalary());
        } 
		return emp;
	}
	
//	public List<Employee> fetchHighSalaryEmployees(){
//		List<EmployeeEntity> entities = repo.findAll();
//		return entities.stream()
//				.filter(e -> e.getSalary() > 45000)
//				.map(e-> {
//				Employee emp = new Employee();
//				emp.setId(e.getId());
//				emp.setName(e.getName());
//				return emp;
//		}).collect(Collectors.toList());
//	}
}