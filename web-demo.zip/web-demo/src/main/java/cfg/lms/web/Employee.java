package cfg.lms.web;

import lombok.Data;

@Data 
public class Employee {
	
	private int empId;
	private String name;
	private double salary;
}
