package cfg.lms.web;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloController {
	 
//	@GetMapping("/")
//	public String greet() {
//		return "Welcome to GET LMS";
//	}
//	
//	@PostMapping("/")
//	public String welcome() {
//		return "Welcome to POST LMS";
//	}
	
//	@GetMapping("/fetch-employee")  //http://localhost:8080/fetch-employee?empId=101&IsContractor=true
//	public void fetchEmployee(@RequestParam("empId") String empID,
//			@RequestParam("IsContractor") String IsContractor) {
//		System.out.println(empID+"----"+IsContractor);
//	}
//	
//	
//	@GetMapping("/checkUser/{id}/{name}")  //http://localhost:8080/checkUser/100/bhagath
//	public String checkUser(@PathVariable("id") int id,
//			@PathVariable("name") String name) {
//		String isPermanent = "true";
//		
//		if(id==10&name.equals("bhagath")) {
//			return isPermanent = "false";
//		}
//		return isPermanent;
//	}
//	
//	
//	@PostMapping("/login")   //http://localhost:8080/login
//	public String login(@RequestBody UserDTO user) {
//		if(user.getUsername().equalsIgnoreCase(user.getPassword())) {
//			return "login success";
//		}
//		else {
//			return "login failed";
//		}
//	}
	
	
//	@GetMapping("/fetch-employee-data")
//	public void fetchEmployee(@RequestParam("empId") String empID,
//			@RequestParam("empName") String empName) {
//		System.out.println(empID+"----"+empName);
//	}
	
	
//	@GetMapping("/fetch-employee-Data")
//	public List<Employee> fetchEmployeeData() {
//		Employee emp = new Employee();
//		emp.setEmpId(101);
//		emp.setName("bhagath");
//		emp.setSalary(256.41);
//		
//		Employee emp1 = new Employee();
//		emp1.setEmpId(102);
//		emp1.setName("Krishna");
//		emp1.setSalary(147.35);
//		
//		List<Employee> employees = new ArrayList<Employee>();
//		employees.add(emp);
//		employees.add(emp1);
//		
//		return employees;
//	}
//	
	
	
    
}
