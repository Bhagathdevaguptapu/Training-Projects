package cfg.lms.web;

import lombok.Data;

@Data
public class UserDTO {
	
	private String username;
	
	private String password;
}
