package cfg.lms.web;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication(scanBasePackages = "cfg.lms" )
@EntityScan("cfg.lms")
@EnableJpaRepositories("cfg.lms")
public class WebDemoApplication {
	
	public static void main(String[] args) {
		 SpringApplication.run(WebDemoApplication.class, args);
	}
}




